﻿using System.Windows;

namespace Pack_Track
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Any application-level initialization can be done here
        }
    }
}